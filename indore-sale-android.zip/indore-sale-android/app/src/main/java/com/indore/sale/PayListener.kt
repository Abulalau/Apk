package com.indore.sale

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class PayListener : NotificationListenerService() {
    private var lastKey = ""
    private var lastT = 0L

    private val amtRe = Regex("(?:₹|rs\\.?|inr)\\s?([0-9][0-9,]*(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE)
    private val creditRe = Regex("received|credited|paid you|sent you|added to|जमा|प्राप्त|मिले|\\bcr\\b", RegexOption.IGNORE_CASE)
    private val badRe = Regex("debited|you paid|you sent|paid to|sent to|withdrawn|debit|failed|declined|request|reminder|offer|cashback", RegexOption.IGNORE_CASE)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val p = sbn.packageName ?: return
        if (p == packageName) return
        val ok = listOf("phonepe", "paisa", "paytm", "npci", "bank", "messag", "mms", "bhim", "mshop", "sms")
            .any { p.contains(it, true) }
        if (!ok) return
        val e = sbn.notification?.extras ?: return
        val text = listOf("android.title", "android.text", "android.bigText")
            .joinToString(" ") { e.getCharSequence(it)?.toString() ?: "" }
        if (!creditRe.containsMatchIn(text) || badRe.containsMatchIn(text)) return
        val raw = amtRe.find(text)?.groupValues?.get(1)?.replace(",", "") ?: return
        val v = raw.toDoubleOrNull() ?: return
        if (v <= 0) return
        val amt = String.format(Locale.US, "%.2f", v)
        val key = amt + "|" + (e.getCharSequence("android.title") ?: "")
        val now = System.currentTimeMillis()
        if (key == lastKey && now - lastT < 15000) return
        lastKey = key; lastT = now

        val sp = getSharedPreferences("bank", 0)
        val arr = try { JSONArray(sp.getString("log", "[]")) } catch (x: Exception) { JSONArray() }
        arr.put(JSONObject().put("id", now).put("amt", amt).put("src", p))
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - 100) until arr.length()) out.put(arr.get(i))
        sp.edit().putString("log", out.toString()).apply()
        Voice.say(applicationContext, amt)
    }
}
