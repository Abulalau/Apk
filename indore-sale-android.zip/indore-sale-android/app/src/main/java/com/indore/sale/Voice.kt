package com.indore.sale

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Voice {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    fun say(c: Context, amt: String) {
        val a = if (amt.endsWith(".00")) amt.dropLast(3) else amt
        val text = "इन्दौर फैशन सेल पर $a रुपये प्राप्त हुए।"
        if (tts == null) {
            pending = text
            tts = TextToSpeech(c.applicationContext) { s ->
                if (s == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("hi", "IN")
                    tts?.setSpeechRate(0.85f)
                    ready = true
                    pending?.let { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "p"); pending = null }
                }
            }
        } else if (ready) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "p")
        } else pending = text
    }
}
